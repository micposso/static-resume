new fullpage('#fullpage', {
	menu: '#navigation',
	anchors:['about', 'web', 'teaching', 'marketing', 'ux', 'immersive', 'education', 'speaking'],
	autoScrolling:true,
	scrollHorizontally: true
});